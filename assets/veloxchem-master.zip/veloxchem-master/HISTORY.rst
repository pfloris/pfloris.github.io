=======
History
=======

All notable changes to this project will be documented in this file.

The format is based on `Keep a Changelog <https://keepachangelog.com/en/1.0.0/>`_, 
and this project adheres to `Semantic Versioning <https://semver.org/spec/v2.0.0.html>`_.

1.0-rc_ (2020-02-28)
--------------------

First release candidate

1.0-rc2_ (2021-04-23)
---------------------

Second release candidate

1.0-rc3_ (2022-11-09)
---------------------

Third release candidate

.. _1.0-rc: https://gitlab.com/veloxchem/veloxchem/-/tree/v1.0-rc
.. _1.0-rc2: https://gitlab.com/veloxchem/veloxchem/-/tree/v1.0-rc2
.. _1.0-rc3: https://gitlab.com/veloxchem/veloxchem/-/tree/v1.0-rc3
