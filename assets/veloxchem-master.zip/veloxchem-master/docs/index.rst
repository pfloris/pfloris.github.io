.. VeloxChem documentation master file, created by
   sphinx-quickstart on Tue Jun  4 10:20:13 2019.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to VeloxChem's documentation!
=====================================

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   introduction.rst
   installation.rst
   gettingstarted.rst

   history.rst
   authors.rst

   api/modules.rst


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
