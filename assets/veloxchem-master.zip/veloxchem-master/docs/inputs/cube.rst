Visualization
-------------

+ Generating cube files

  .. literalinclude:: cube.inp
     :language: bash

