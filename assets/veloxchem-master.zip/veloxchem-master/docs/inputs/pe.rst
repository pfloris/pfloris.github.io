Environment
-----------

+ Self-consistent field calculation with polarizable environment

  .. literalinclude:: pe.inp
     :language: bash


+ Example potential file

  .. literalinclude:: pe.pot
     :language: bash

