Correlated method
-----------------

+ Second-order Møller--Plesset perturbation

  .. literalinclude:: mp2.inp
     :language: bash

