Self-Consistent Field
---------------------

+ Spin-restricted Hartree-Fock

  .. literalinclude:: scf.inp
     :language: bash


+ Spin-unrestricted Hartree-Fock

  .. literalinclude:: uhf.inp
     :language: bash

