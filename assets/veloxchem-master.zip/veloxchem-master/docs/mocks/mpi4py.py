from unittest.mock import Mock
MPI = Mock()
