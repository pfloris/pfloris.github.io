from unittest.mock import MagicMock as Mock
array = Mock()
ndarray = Mock()
