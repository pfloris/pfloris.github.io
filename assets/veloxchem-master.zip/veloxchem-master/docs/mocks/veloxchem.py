from unittest.mock import Mock
main = Mock()
