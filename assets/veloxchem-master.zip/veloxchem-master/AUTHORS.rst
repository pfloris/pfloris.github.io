=======
Credits
=======

Development lead
----------------

* Xin Li
* Zilvinas Rinkevicius

Contributors
------------

* Olav Vahtras
* Manuel Brand
* Nanna H. List
* Magnus Ringholm
* Karan Ahmadazdeh
* Roberto Di Remigio
* Maximilian Scheurer
* Michael F. Herbst

These lists were obtained 2020-11-17 by running ``git shortlog -sn``
